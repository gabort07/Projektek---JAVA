package csere;

public class Csere {
    
    public static void main(String[] args) {
        int a = 7;
        int b = 3;
        // Ide írjuk az új sorokat
        
        System.out.println("a="+a+"; b="+b);
    }
}
